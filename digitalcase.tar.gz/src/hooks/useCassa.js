import { useState, useCallback, useEffect } from 'react'

export function useCassa() {
  const [inputCents, setInputCents] = useState(0)
  const [righe, setRighe] = useState([])
  const [scontrinoAperto, setScontrinoAperto] = useState(false)
  const [ultimaChiusa, setUltimaChiusa] = useState(null)

  // Carica da sessionStorage solo lato client
  useEffect(() => {
    try {
      const saved = sessionStorage.getItem('cassa_righe')
      if (saved) {
        const parsed = JSON.parse(saved)
        if (parsed.length > 0) setRighe(parsed)
      }
      if (sessionStorage.getItem('cassa_aperto') === 'true') setScontrinoAperto(true)
    } catch {}
  }, [])

  // Sincronizza con sessionStorage
  useEffect(() => {
    try { sessionStorage.setItem('cassa_righe', JSON.stringify(righe)) } catch {}
  }, [righe])

  useEffect(() => {
    try { sessionStorage.setItem('cassa_aperto', String(scontrinoAperto)) } catch {}
  }, [scontrinoAperto])
  const [errore, setErrore] = useState('')

  const pressDigit = useCallback((digit) => {
    setErrore('')
    setUltimaChiusa(null)
    setInputCents(prev => {
      const str = String(prev) + String(digit)
      const val = parseInt(str, 10)
      return val > 9999999 ? prev : val
    })
  }, [])

  const pressDoubleZero = useCallback(() => {
    setErrore('')
    setUltimaChiusa(null)
    setInputCents(prev => {
      const str = String(prev) + '00'
      const val = parseInt(str, 10)
      return val > 9999999 ? prev : val
    })
  }, [])

  const pressClear = useCallback(() => {
    setInputCents(0)
    setErrore('')
  }, [])

  const caricaRigheEsterne = useCallback((righeEserne) => {
    setRighe(righeEserne)
  }, [])

  const aggiungiRiga = useCallback((reparto, sottoreparto = null) => {
    const importo = sottoreparto ? sottoreparto.prezzoFisso : inputCents
    const nome = sottoreparto ? sottoreparto.nome : reparto.nome
    const iva = sottoreparto?.ivaOverride ?? reparto.iva
    const massimoImporto = sottoreparto ? sottoreparto.massimoImporto : reparto.massimoImporto
    const minimoImporto = sottoreparto ? sottoreparto.minimoImporto : reparto.minimoImporto

    if (importo <= 0) { setErrore('Importo non valido'); return false }
    if (importo > massimoImporto) {
      setErrore(`Supera il massimo €${fmt(massimoImporto)} per ${nome}`); return false
    }
    if (importo < minimoImporto) {
      setErrore(`Sotto il minimo €${fmt(minimoImporto)} per ${nome}`); return false
    }

    const nuovaRiga = {
      id: sottoreparto?.id || (Date.now() + Math.random()),
      nome, importo, iva,
      colore: reparto.colore,
      icona: reparto.icona,
      repartoId: reparto.id,
      sottoRepartoId: sottoreparto?.id || null,
      giacenza: sottoreparto?.giacenza ?? null,
      giacenzaMinima: sottoreparto?.giacenzaMinima ?? null,
    }

    setRighe(prev => {
      const idx = prev.findIndex(r =>
        r.nome === nuovaRiga.nome &&
        r.importo === nuovaRiga.importo &&
        r.repartoId === nuovaRiga.repartoId
      )
      if (idx >= 0) {
        const aggiornato = [...prev]
        aggiornato[idx] = {
          ...aggiornato[idx],
          quantita: (aggiornato[idx].quantita || 1) + 1,
          totaleRiga: ((aggiornato[idx].quantita || 1) + 1) * nuovaRiga.importo
        }
        return aggiornato
      }
      setScontrinoAperto(true)
      return [...prev, { ...nuovaRiga, quantita: 1, totaleRiga: nuovaRiga.importo }]
    })

    setInputCents(0)
    setErrore('')
    return true
  }, [inputCents])

  const annullaUltima = useCallback(() => {
    setRighe(prev => {
      if (prev.length === 0) return prev
      const nuove = [...prev]
      const ultima = nuove[nuove.length - 1]
      if (ultima.quantita > 1) {
        nuove[nuove.length - 1] = {
          ...ultima,
          quantita: ultima.quantita - 1,
          totaleRiga: (ultima.quantita - 1) * ultima.importo
        }
      } else {
        nuove.pop()
      }
      return nuove
    })
  }, [])

  // Elimina riga specifica per id
  const eliminaRiga = useCallback((id) => {
    setRighe(prev => prev.filter(r => r.id !== id))
  }, [])







  function aggiornaQuantita(id, delta) {
    setRighe(prev => prev
      .map(r => r.id === id
        ? { ...r,
            quantita: Math.max(0, r.quantita + delta),
            totaleRiga: r.importo * Math.max(0, r.quantita + delta)
          }
        : r
      )
      .filter(r => r.quantita > 0)
    )
  }










  const annullaTutto = useCallback(() => {
    setRighe([])
    setInputCents(0)
    setErrore('')
    setUltimaChiusa(null)
    setScontrinoAperto(false)
    try { sessionStorage.removeItem('cassa_righe'); sessionStorage.removeItem('cassa_aperto') } catch {}
  }, [])

  const ripristinaRighe = useCallback((righeBackup) => {
    setRighe(righeBackup)
    setInputCents(0)
  }, [])

  const chiudiScontrino = useCallback(() => {
    if (righe.length === 0) return null
    const scontrino = {
      id: 'SC' + Date.now(),
      righe: [...righe],
      totale: righe.reduce((s, r) => s + r.totaleRiga, 0),
      timestamp: new Date().toISOString(),
    }
    setUltimaChiusa(righe[righe.length - 1])
    setRighe([])
    setInputCents(0)
    return scontrino
  }, [righe])

  const totale = righe.reduce((s, r) => s + r.totaleRiga, 0)
  const subtotalePerIva = righe.reduce((acc, r) => {
    const k = String(r.iva)
    acc[k] = (acc[k] || 0) + r.totaleRiga
    return acc
  }, {})

  function salvaNota(id, nota, tipo = 'rimozione', costoAggiunta = 50) {
    setRighe(prev => prev.map(r => {
      if (r.id !== id) return r
      // Rimuovi eventuale costo aggiunta precedente
      const importoBase = r.importoBase ?? r.importo
      const totaleBase = importoBase * r.quantita
      if (tipo === 'aggiunta' && nota) {
        return {
          ...r,
          nota: `+${nota}`,
          importoBase,
          importo: importoBase + costoAggiunta,
          totaleRiga: totaleBase + (costoAggiunta * r.quantita),
        }
      } else {
        return {
          ...r,
          nota: nota ? `-${nota}` : '',
          importoBase,
          importo: importoBase,
          totaleRiga: totaleBase,
        }
      }
    }))
  }

  function applicaSconto(tipo, valore) {
    if (tipo === 'euro') {
      // Stessa logica della cassa: input in centesimi
      const scontoCents = parseInt(valore) || 0
      if (scontoCents <= 0 || scontoCents >= totale) return false
      setRighe(prev => {
        // Aggiunge una riga sconto negativa
        return [...prev, {
          id: Date.now(),
          nome: `Sconto -€${(scontoCents/100).toFixed(2).replace('.',',')}`,
          importo: -scontoCents,
          iva: 0,
          colore: '#ff4d6a',
          icona: 'tag',
          repartoId: null,
          sottoRepartoId: null,
          quantita: 1,
          totaleRiga: -scontoCents,
        }]
      })
    } else {
      const perc = parseFloat(valore.replace(',','.'))
      if (perc <= 0 || perc >= 100) return false
      const scontoCents = Math.round(totale * perc / 100)
      setRighe(prev => [...prev, {
        id: Date.now(),
        nome: `Sconto ${perc}%`,
        importo: -scontoCents,
        iva: 0,
        colore: '#ff4d6a',
        icona: 'tag',
        repartoId: null,
        sottoRepartoId: null,
        quantita: 1,
        totaleRiga: -scontoCents,
      }])
    }
    return true
  }

  return {
    inputCents, righe, ultimaChiusa, errore, totale, subtotalePerIva,
    pressDigit, pressDoubleZero, pressClear,
    aggiungiRiga, caricaRigheEsterne, annullaUltima, eliminaRiga, annullaTutto,
    chiudiScontrino, ripristinaRighe,aggiornaQuantita, applicaSconto, scontrinoAperto, salvaNota,
    resetScontrinoAperto: () => setScontrinoAperto(false),
    apriScontrino: () => setScontrinoAperto(true)
  }
}

function fmt(cents) {
  return (cents / 100).toFixed(2).replace('.', ',')
}
